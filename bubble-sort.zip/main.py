'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
def performBubbleSort(nums):
    n=len(nums)
    fixThisIndex = n-1
    while fixThisIndex >0:
        for index in range(fixThisIndex):
            if nums[index] > nums[index+1]:
                temp = nums[index]
                nums[index]=nums[index+1]
                nums[index+1]=temp
        print(nums)        
        fixThisIndex-=1        
                

nums = [10,8,2,14,12,7]    
print("before sorting : ",nums)

 
performBubbleSort(nums) 
print("after sorting : ",nums)