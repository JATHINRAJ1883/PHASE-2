class Node:
    def __init__(self, data):
        self.data = data 
        self.left = None 
        self.right = None    
        
class Solution(object):
    def maxLevelSum(self, root):
        if root == None:
            return 0
        Q = [root]
        resultLevel = 0 
        resultSum = -100000000
        currLevel = 1
        while len(Q) > 0:
            n = len(Q)
            currSum = 0
            for i in range(n):
                 # step-1 (Deleting)
                currNode = Q.pop(0)
 
                 # step-2 (Appending to subResult)
                currSum += currNode.val
 
                # step-3 (Enquing the left child)
                if currNode.left != None:
                    Q.append(currNode.left)
 
                 # step-4 (Enquing the right child)
                if currNode.right != None:
                    Q.append(currNode.right)
 
            if currSum > resultSum:
                resultSum = currSum 
                resultLevel = currLevel 
            currLevel += 1
        return resultLevel 
obj1 = Node(100)
obj2 = Node(21)
obj3 = Node(-151)
obj4 = Node(87)
obj5 = Node(12)
obj6 = Node(52)
obj7 = Node(8)
obj8 = Node(27)
obj9 = Node(28)
obj10 = Node(7)



obj1.left=obj2
obj1.right=obj3
obj2.left=obj4
obj2.right=obj5
obj3.left=obj6
obj3.right=obj7
obj4.right=obj8
obj5.right=obj9
obj7.left=obj10

maxLevelSum(obj1)


'''
Programs on Linked list:
    1. Linked list construction and printing 
    2. Insertion at tail 
    3. Insertion at head 
    4. Insertion at specific position 
    5. Deletion at tail 
    6. Deletion at head 
    7. Deletion at specific position
 
 
Programs on Stacks and Queues:
    1. Stack implementation 
    2. Queue implementation 
    3. valid brackets solution 
    4. valid brackets solution (Extended version)
 
 
Programs from Searching:
    1. Linear Search 
    2. Binary Search 
 
Program from Sorting:
    1. Bubble sort 
    2. Selection sort 
    3. Insertion sort 
    4. Merge sort
 
Programs on Trees:
    1. Preorder traversal
    2. Inorder traversal
    3. Postorder traversal
    4. Level order traversal 
    5. Max sum problem solution 
    6. Left view of Binary Tree 
    7. Right view of Binary Tree 
    '''