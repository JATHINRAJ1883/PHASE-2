'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
def performselectionsort(nums):
    n=len(nums)
    fixthisindex = n - 1
    while fixthisindex>0:
        maxeleindex = fixthisindex
        for index in range(fixthisindex):
            if nums[index] > nums[maxeleindex]:
                maxeleindex = index
        if maxeleindex!=fixthisindex:
            temp=nums[maxeleindex]
            nums[maxeleindex]=nums[fixthisindex]
            nums[fixthisindex]=temp
        print(nums)
        fixthisindex-=1
    
nums=[10,2,8,4,14,9,1]    
print("before sorting :",nums)

performselectionsort(nums)
print("after sorting : ",nums)