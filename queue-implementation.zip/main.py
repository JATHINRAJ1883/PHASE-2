'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
# queue implementation
def enqueue(Q,ele):
    Q.append(ele)
    print(ele,"inserted into queue")
    print(Q)

def dequeue(Q):
    if len(Q) == 0:
        print("queue is empty")
        return
    print(Q[0],"is getting deleted")
    Q.pop(0)
    print(Q)
    
Q=[]
enqueue(Q,11)
enqueue(Q,21)
enqueue(Q,31)
enqueue(Q,41)
enqueue(Q,51)


dequeue(Q)
dequeue(Q)
dequeue(Q)
dequeue(Q)
dequeue(Q)
dequeue(Q)
