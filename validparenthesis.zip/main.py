'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
def validParentesis(word) :
     stack=[]
    for char in word:
        if char == '(' or char == '[' or char == '{':
            stack.append(char)
        else:
            if len(stack)==0:
                return False
            else :
                stack.pop()
                
    if len(stack)==0:
        return True
    return False
    
word = input()
result=validParentesis(word)
print(result)
'''
class Solution:
    def isValid(self, s: str) -> bool:
        while "()" in s or "[]" in s or "{}" in s:
            s = s.replace("()",'')
            s = s.replace("[]",'')
            s = s.replace("{}","")
        
        if len(s):
            return(0)
        else:
            return 1
- - - --------------------------------------------------------------------->            
    class Solution(object):
    def isValid(self, s):
        stack = []
        openBrackets = ["(", "{", "["]
        for ele in s:
            if ele in openBrackets:
                stack.append(ele)
            else:
                if len(stack) == 0:
                    return False 
                elif ele == ')':
                    if stack[-1] == '(':
                        stack.pop()
                    else:
                        return False
                elif ele == ']':
                    if stack[-1] == '[':
                        stack.pop()
                    else:
                        return False
                elif ele == '}':
                    if stack[-1] == '{':
                        stack.pop()
                    else:
                        return False
        if len(stack) == 0:
            return True 
        return False        

'''